$(function(){
    let Pj01Img = $('.all .left figure img');
    let item = $('.item'); 

    item.mouseenter(function(){
        console.log($(this).index())
        let imgIndex = $(this).index() + 1;
        Pj01Img.attr('src','img/img0'+ imgIndex + '.jpg')
    })
})